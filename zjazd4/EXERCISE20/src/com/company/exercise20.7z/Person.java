package com.company;

public class Person {
    protected String name;  //pola
    protected String address; // protected, poniewaz ma miec dostep tez w dziedziczacej

    public Person(String name, String address) {        //konstruktor
        this.name = name;
        this.address = address;       //przypisanie do pól
    }

    public String getName() {
        return this.name;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String toString() {
        String s = "Person[name=" + this.name + ",address=" + this.address + "]";
        return s;
    }
}